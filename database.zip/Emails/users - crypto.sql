-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 22, 2023 at 07:46 PM
-- Server version: 5.7.42
-- PHP Version: 8.1.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cryptoss_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `account_balance` int(11) NOT NULL,
  `active_balance` int(11) NOT NULL,
  `initial_deposit` int(11) DEFAULT NULL,
  `plan_id` bigint(20) UNSIGNED DEFAULT NULL,
  `expires_in` int(11) DEFAULT NULL,
  `referral` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`id`, `username`, `email`, `photo`, `email_verified_at`, `account_balance`, `active_balance`, `initial_deposit`, `plan_id`, `expires_in`, `referral`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(7, 'Clinton', 'Cryptostake191@gmail.com', 'profiles/ljuAL16DeCs1HT6PqcE747yLePH4lvo1U3sGk81n.jpg', '2022-07-13 02:51:34', 2200, 50350, NULL, NULL, NULL, NULL, '$2y$10$E2qnwRaiHKdvGgJrSnuy5.K5TkrL0ILsOwNWAkbg3VyEQHKMLxTia', 'qUuuQNi93Bn0x4HeTCAcabhgrdxrBAU25jHVUHMLyGgZSQuMn6r5xkVXvXZ3', '2022-07-23 02:51:48', '2022-09-20 07:00:02'),
(20, 'Ethel', 'ethelihims18@gmail.com', 'images/empty.jpg', '2022-07-23 16:51:38', 100, 0, NULL, NULL, NULL, NULL, '$2y$10$V8pgyM/cCcyo3mHT8UsoNOG/YFw3R09bTlJ4TmLOz1XNhUz840I22', NULL, '2022-07-23 16:46:20', '2022-07-23 16:53:32'),
(21, 'Tab bless', 'tabbless36@gmail.com', 'images/empty.jpg', NULL, 0, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$RrNEXkrdNUblvLDhWzNGM.jMWRPrWf9b.v09TRG97j3OOXNXEzbem', NULL, '2022-07-23 17:38:35', '2022-07-23 17:38:35'),
(22, 'MbianyohNelson', 'Mbianyohnelson@gmail.com', 'images/empty.jpg', '2022-07-24 19:21:43', 2100, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$SmfEl3B/5/PTXfK00V69Ve7LI.N/2DS/Aoy4A.sxyvpBgW2TLPTMK', 'l0i745BopXotoBull0FqrINwuff0JziC8Ug9WQFZqVpuk7EWq5ebmp7FycTb', '2022-07-24 19:20:48', '2022-09-03 10:27:17'),
(23, 'Gilbert enow', 'gilbertenow@yahoo.com', 'images/empty.jpg', NULL, 0, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$Q2csqY5py6dauL0YxVOYtO1msYU4PwcyO2AucbmJZmt3QjerHN602', NULL, '2022-07-25 19:05:31', '2022-07-25 19:05:31'),
(24, 'judith45', 'judith45@gmail.com', 'profiles/OmCkCa3PgQYCDDm77C96iV3D8KzxZ1Cm0lQk8FqZ.jpg', '2022-07-25 19:11:08', 3350, 16750, NULL, NULL, NULL, NULL, '$2y$10$hmlYj4cYXMqwF/iFggQFfuyuQAyUOneAeY3SFygpy9aJHsexGQO4u', NULL, '2022-07-25 19:09:59', '2022-10-02 07:00:02'),
(25, 'Boula', 'sambosaliou@gmail.com', 'profiles/sDvXepR5LsXCw9NiejpUazAR1cd9gNhJ7B1m4yBA.jpg', NULL, 0, 0, NULL, NULL, NULL, NULL, '$2y$10$mbxQERV9Xzy0JsX9xvf1RO9T0Q091BuUbwpwKqgEkQfKtvPCfwQ6y', NULL, '2022-07-26 03:07:48', '2022-07-26 03:07:48'),
(26, 'Ernestine', 'beriyuyernestine@gmail.com', 'images/empty.jpg', '2022-08-09 16:39:12', 0, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$nqzaZOBIwJtem2IJsxNvUuv4kHeLTp6XMfNlSzLv5JcVzW.tKUXTy', NULL, '2022-07-27 03:37:16', '2022-07-27 03:37:16'),
(27, 'demo', 'techwebdev3@gmail.com', NULL, '2022-07-27 14:29:02', 18000, 10100, NULL, NULL, NULL, NULL, '$2y$10$iJWlCHNoDUbLI5.twMhn8uA8oBRD0PRQ3OUdrEoZiB0Ng6w.eiTf.', 'NYGNgnqaOQ5H4GLQpUgZ9kR6Yzs7TpnqYFrKhsH72wfODF1v2Ghr2eRg9wYk', NULL, '2022-08-26 18:00:31'),
(28, 'Riddick', 'riddickclarks@gmail.com', 'images/empty.jpg', '2022-07-27 23:49:02', 0, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$dEWKqGIMx5Fyr1rFT90nU.Fnenim17kjokU45eYf1oi4OAYZRfNva', '4kJGuzyRLxhDqbYn7rMFStSiRBbsjb0gGNrhkp6GKppjENMNtN1VLHwL6LX7', '2022-07-27 22:11:15', '2022-07-27 23:49:02'),
(29, 'Joliva', 'Abouirim@icloud.com', 'images/empty.jpg', NULL, 0, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$SK89t5SvHs0969Wc4Xq7/uzuHqPQyt9sb0w6VD7fTJJ5X1.gGKCie', NULL, '2022-07-27 23:05:54', '2022-07-27 23:05:54'),
(30, 'Emilia Nahbila', 'nahbilaemilia@gmail.com', 'images/empty.jpg', NULL, 0, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$J8bFY.kjrKbcytYFVBLp9ukvUSBqvp3BPokjWgHe4lv2sxS.B3/p2', NULL, '2022-07-28 04:33:07', '2022-07-28 04:33:07'),
(31, 'Ladyzee', 'zeenatlobe88@gmail.com', 'images/empty.jpg', '2022-07-29 17:34:25', 0, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$toDui.8gtYNjCpNKdtnzGe5UDB5aqhnV/aFOt560apMBmB0aEwV8q', NULL, '2022-07-29 17:32:32', '2022-07-29 17:34:25'),
(32, 'Mambo macbright', 'macmambo44@gmail.com', 'images/empty.jpg', NULL, 0, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$R.78aDK7Xty8wL/RZRZN1OWqX4ZdZhssiM2RCPEeNdcgMjTJAbR7G', NULL, '2022-07-29 22:46:08', '2022-07-29 22:46:08'),
(33, 'Akwenbrite', 'akwenner7@gmail.com', 'images/empty.jpg', '2022-07-30 05:32:28', 0, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$MAMXe1kW0GiyoK0dXRehkO/Vz0nvF2wprApX1nWSc67r12YmguCvC', 'gtOWgIDRh52RrlGSwbC2hYF2DtaxvFygF0TYlTduLC11lv09oISOVZGNmVfT', '2022-07-30 05:31:06', '2022-07-30 05:32:28'),
(34, 'ebule stephen', 'ebulestephen7@gmail.com', 'images/empty.jpg', NULL, 0, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$z5SAoet3WL73uqNZasvU9OQfnPwgIB0CQVlkEYpHld9KI8lDZLEAW', NULL, '2022-07-30 17:13:22', '2022-07-30 17:13:22'),
(35, 'Martino 4', 'akemfuamartin0@gmail.com', 'images/empty.jpg', NULL, 0, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$9Cc9hIk8xTGDDMvWoBqBEu8GWIl2uBZ/iETKlZcNFP3fSLQIFsPRi', NULL, '2022-07-30 18:16:03', '2022-07-30 18:16:03'),
(36, 'My Queen', 'joansonetengenengenowagbor@gmail.com', 'profiles/crZ2NYBVWgSmX18RSDrT6BVElw3l3TBRUuX25YWL.jpg', NULL, 0, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$cYFI5kGZOGtNBjvutbjjJeZIaljZDQgTVAC3hGD18dpPHy0mCh75K', NULL, '2022-07-30 19:43:22', '2022-07-30 19:43:22'),
(37, 'moscovite', 'rodrigueokobe@gmail.com', 'images/empty.jpg', '2022-07-30 20:05:00', 100, 20100, NULL, NULL, NULL, 'MbianyohNelson', '$2y$10$/UvNerNokWTe5Wy7R5FI8Ooz4fMCDhFArBqLgpdWUKOE6vXW1Lfze', NULL, '2022-07-30 19:44:29', '2022-10-03 07:00:01'),
(38, 'Olive190', 'olivekounou96@gmail.com', 'images/empty.jpg', '2022-08-07 19:41:47', 0, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$vR70z6v1FrD5lutB/OANUeiWFkPchseYTZKbel1iMgIsq117L6t/m', '8B2fy5fCNQOZBWsPzad7lDg1RmIDKj1QgqFU46poLYl4gfNWnqRPOt6gDohA', '2022-07-30 20:00:20', '2022-08-07 19:41:47'),
(39, 'Ntoh1234', 'connyntoh@gmail.com', 'images/empty.jpg', '2022-07-30 20:40:04', 0, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$q1vCNJUuNbAp6Bq3qvKkNO1H9lMu3bdpptQPCnDluUJ3eQuZp1Ptm', 'QPXJcUfl6rHx8tdFuyvnRBnAhdwrZqGC58jlPc04uKOYMjyMDDUBJu3LRAwx', '2022-07-30 20:31:54', '2022-07-30 20:40:04'),
(40, 'Edembu', 'blessonemaziri@gmail.com', 'images/empty.jpg', NULL, 0, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$giRYcivA28d/SiPrBxtTX.qdf3ozcKar0D0OP3mJyq866pnIzWnUO', NULL, '2022-07-30 23:07:43', '2022-07-30 23:07:43'),
(41, 'Linda', 'lindandip87@gmail.com', 'images/empty.jpg', NULL, 0, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$R0Lqmu0pc6ituFinWFLcp.ICB/ul25nhUN0IX.zKECLIKNnOWuNCO', NULL, '2022-07-30 23:48:09', '2022-07-30 23:48:09'),
(42, 'Tabotoj', 'Tabotnkpotojong@gmail.com', 'images/empty.jpg', NULL, 0, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$jUFnWtkHhYs0myogIkNzR.EuHR0JHdf8CVk45Qy90aFuLEvsfM.N6', NULL, '2022-07-30 23:49:03', '2022-07-30 23:49:03'),
(43, 'Jamess', 'jamesjako240@gmail.com', 'images/empty.jpg', NULL, 0, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$wlMK81xvofeUWIMTyI3klOodj3b6kfIGKA6tLGZJH9VCK/4EJ7BHu', NULL, '2022-07-31 23:28:36', '2022-07-31 23:28:36'),
(44, 'Cho Desire', 'Choskipe@gmail.com', 'images/empty.jpg', NULL, 0, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$HcMOyajKNdYo3czCVjOcR.CaC/2QCupexccwpKG1v2ObEziA9sIwW', NULL, '2022-08-01 01:12:10', '2022-08-01 01:12:10'),
(45, 'Said19', 'saidassan90@gmail.com', 'images/empty.jpg', '2022-08-13 04:36:34', 0, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$DModwISeTSsReeo8ubFaZOQ6Z/AoHxjs2ZnqEwzFhoUUwx8n2L4p2', 'MQg8C8COXphac4uKX94wy9lVj9SGT7AEK6TkyNMskIgbXn4i8v1qZtYKnnVQ', '2022-08-01 04:06:54', '2022-08-13 04:36:34'),
(46, 'Abdel Aziz', 'abdelaziz.gouloure6019@gmail.com', 'images/empty.jpg', NULL, 0, 0, NULL, NULL, NULL, 'MbianyohNelson', '$2y$10$OY5VVU6Y46EHEO0f1o9c4.pwsxFb6vAphYnS1Ucwlqqog4PAy.lIe', NULL, '2022-08-01 08:04:44', '2022-08-01 08:04:44'),
(47, 'Simoney', 'tayuisimon@yahoo.com', 'images/empty.jpg', '2022-08-01 18:06:15', 0, 0, NULL, NULL, NULL, NULL, '$2y$10$u0QnPNSRCw95h5jVMS..TO0EL55iLa0A.j8tLiQmN5vS/tcUZp2py', 'UbBsfbL4xdnlYDIWFCi3haT28pAnmFYMUD4Lf6nAQybcjZjqX9xIFGkm2wit', '2022-08-01 18:00:23', '2022-08-01 18:06:15'),
(48, 'Frank', 'Frankmosaso2002@gmail.com', 'images/empty.jpg', '2022-08-02 23:12:18', 0, 0, NULL, NULL, NULL, 'MbianyohNelson', '$2y$10$VVQn2sy7p4tr1Xmk8VVF/u/hOJRMSTDGWbRhu0GyJIdE.jzz9tKY2', '1QjVAlr8o3kYVxCDxY4nuWlZhPCk29DgUYlmSgYIRIp1fq4O4JO5WOFpgwzb', '2022-08-02 23:09:57', '2022-08-02 23:12:18'),
(49, 'Charles', 'rushjohn735@gmail.com', 'images/empty.jpg', NULL, 0, 0, NULL, NULL, NULL, NULL, '$2y$10$zovkrUK4807FkZa7vIK1e.jfn7ehxQWiJX46vKe2LlGwuoRagET/K', NULL, '2022-08-02 23:14:57', '2022-08-02 23:14:57'),
(50, 'Smile', 'Yeteblue3@gmail.com', 'images/empty.jpg', '2022-08-03 22:30:16', 0, 0, NULL, NULL, NULL, NULL, '$2y$10$cU5iE6bwRdPXVC.2u5dBN.t0ZqkkRmZeyGwLqVHWyItk0vARcw0wy', NULL, '2022-08-03 22:29:03', '2022-08-03 22:30:16'),
(51, 'Tata ishaga', 'tataishaga@gmail.com', 'images/empty.jpg', '2022-08-07 20:08:34', 0, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$MzQ7qn2/Tu8jfUtk4G0mRu8btFk7A8RH7BPajFrV/QYWvs3ZKU4jW', NULL, '2022-08-07 20:06:46', '2022-08-07 20:08:34'),
(52, 'mazzi', 'agumazzi34@gmail.com', 'images/empty.jpg', '2022-08-07 21:46:35', 0, 0, NULL, NULL, NULL, 'Smile', '$2y$10$smvamSP32rx5.3w.7vEcwuawPAwjtq8BDPtUePsCzic7fk9Imi6xS', NULL, '2022-08-07 21:45:18', '2022-08-07 21:46:35'),
(53, 'Duodou', 'Starboydoudou850@gmail.com', 'images/empty.jpg', '2022-08-08 03:55:45', 0, 0, NULL, NULL, NULL, 'Smile', '$2y$10$bo84Aiij3to3bhmlBg86F.aZzaioIqIw5l/ML38Eu72xmLmjxYbUu', NULL, '2022-08-08 03:46:34', '2022-08-08 03:55:45'),
(54, 'Phalonna', 'phalonnetalla@gmail.com', 'images/empty.jpg', NULL, 0, 0, NULL, NULL, NULL, 'clinton', '$2y$10$Ybkw9CQwpns3Y0N/TwK4lO6yCPPF5jOhmlhaY8Tzoeo9Cs7kZThhu', NULL, '2022-08-08 23:43:25', '2022-08-08 23:43:25'),
(55, 'monjah19998', 'filenmonjah04@gmail.com', 'profiles/vs5roAx3wRO9zLhK9gqyavWVnEKGcyiiFCsix7kv.jpg', NULL, 0, 0, NULL, NULL, NULL, 'clinton', '$2y$10$I60REzbyM7gcX0ISLO3N4uMkVM2CNNjgXS1FScXVnwZBRapkKe5iG', NULL, '2022-08-09 00:08:03', '2022-08-09 00:08:03'),
(56, 'Kissbenji', 'benji.pembe@gmail.com', 'images/empty.jpg', '2022-08-09 02:35:18', 0, 0, NULL, NULL, NULL, NULL, '$2y$10$LLNj8m6KrspiN.G2emSFXeWEpW7EpxN9eQTVft48/wWLhVrReBvoK', NULL, '2022-08-09 02:34:31', '2022-08-09 02:35:18'),
(57, 'Rodriguz', 'paulinmgba@gmail.com', 'profiles/OvMM715MA1DR6gvdQE8zPonet0cocqlYOCBR5doE.jpg', '2022-08-09 03:29:12', 0, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$NuAjUawCOLMfcrXnXknoUeJJ666aj0u1tvfkGZJoVGRsMPvBah2uu', 's2UKJPMIkDZU0AwP2YjF3Jayckrnph1EZG2Zy8A6wJl4K6cghpBReVaIIFEo', '2022-08-09 03:25:13', '2022-08-09 03:29:12'),
(58, 'Aristophane46', 'feupiaristophane46@gmail.com', 'images/empty.jpg', '2022-08-09 03:43:44', 0, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$ibdKFPMFbP2BfgUX9SO1VekPQi5M2IZH9lUgS7.RLEKAXBgGJ0le6', NULL, '2022-08-09 03:43:12', '2022-08-09 03:43:44'),
(59, 'Danielle', 'ekododanielle@gmail.com', 'images/empty.jpg', '2022-08-09 16:33:35', 0, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$rZ60cZYLqNYt7miqYegIZe48e0sTpZInN5d0KLQQINOn6dAwXEGO2', NULL, '2022-08-09 16:32:30', '2022-08-09 16:33:35'),
(60, 'NGARO', 'rogernganta7@gmail.com', 'images/empty.jpg', '2022-08-09 16:42:52', 0, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$fPJ0eNmkC9PXi/klSKxl3Oy3nljG0HGxfp//5BwMCU9brFDKaukkC', NULL, '2022-08-09 16:41:00', '2022-08-09 16:42:52'),
(61, 'ORTEGA Brekson', 'ortegaasoungou47@gmail.com', 'profiles/vnE7nMzLhK4srqTyuYrEQTNrikOBzN5IL3TZPpGF.jpg', '2022-08-10 01:01:59', 0, 0, NULL, NULL, NULL, 'clinton', '$2y$10$S70X5hApfNZ44nEqwKTho.YVKCt.JnSVC4etTYza9RnhF7ZSQ4z.6', NULL, '2022-08-10 00:18:59', '2022-08-10 01:01:59'),
(62, 'BB ranger', 'tabbless04@gmail.com', 'images/empty.jpg', '2022-08-28 21:31:57', 0, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$yGuSkTgkq9h5BzLEo5ky8er92a/sODlsr8W0yTW0qkNKiVcgEwUGm', 'eRuCLE7TyNheoLDQkuoKFReO2aBRd6Rd4AHwY3aAS0Hx85DMYp0NIg7lTab3', '2022-08-10 16:18:24', '2022-08-28 21:31:57'),
(63, 'Angeh Dialet', 'dialetancho@gmail.com', 'images/empty.jpg', '2022-08-11 02:56:02', 2050, 0, NULL, NULL, NULL, 'clinton', '$2y$10$m4oCwzAKC7v4B2XYX0dYrORLqcFr1HERlfoh6iP0twv3euHnTiPHe', NULL, '2022-08-11 02:45:51', '2022-09-09 12:47:32'),
(64, 'Chenwi5', 'gilbertchenwi0@gmail.com', 'images/empty.jpg', '2022-08-11 11:39:41', 0, 0, NULL, NULL, NULL, 'clinton', '$2y$10$ZUs06K20FKL08z7hFpkTkOP3TPlbPXIdl5.OUjspDIq8WijaBta4W', NULL, '2022-08-11 11:37:19', '2022-08-11 11:39:41'),
(65, 'Dukandasight', 'songwalters93@gmail.com', 'images/empty.jpg', '2022-08-11 14:46:15', 0, 0, NULL, NULL, NULL, 'clinton', '$2y$10$KjR8kJcmDzsc3xuQfM94weZgWLTfoMU5pfyQWi6xaTzDysSVDP6wq', 'nZpuckUhu3zoQWHxa8TpIMd2mSavE9ftE2a4WpvpzPa3Q8uwE9ndholT3RAq', '2022-08-11 14:45:45', '2022-08-14 23:54:21'),
(66, 'Kumaranzy', 'Kumaransomkfutuah@gmail.com', 'images/empty.jpg', '2022-08-12 03:33:15', 2050, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$kwf/0OUBe3ZnCQFXyUrYG.bZhROfSRG.J8L8aU/FC/9.sJNIvhGBO', 'SUVuRFxe2omOy0LvOJ0Bi5M7gfIPHnyAtF7OKE9cyoKgJtgqTY0mzfinWV74', '2022-08-12 03:28:22', '2022-09-11 09:08:17'),
(67, 'Angyiembe', 'angyiembevioletangatoh@gmail.com', 'images/empty.jpg', '2022-08-12 15:13:35', 0, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$PDV7X5hX.Ccxvc2Qgl77xOqBueB1kIa8CQ9wZ3IkbHM1EQpv.jpj6', 'LlMVVE8MRW4ni0sd1FLAoA6nRU3CXMJGbAPJCg1TGqcS8OTYFRmEWWBDXcf7', '2022-08-12 15:11:57', '2022-08-14 14:40:24'),
(68, 'Joshua', 'apsttekangjoshua033@gmail.com', 'images/empty.jpg', '2022-08-12 19:53:20', 0, 0, NULL, NULL, NULL, 'clinton', '$2y$10$qJAS45bCV.5CBpAOm6tZ4O8vlz3WTg1KbqjZqv38wmS1RrbtD9VNC', 'Bt4UcfTcOWmZW6kjsvDY7pEAXoM4kCkjUO0t0Zd6URXRl4NJrYRa3ibbgvA7', '2022-08-12 19:42:33', '2022-08-12 19:53:20'),
(69, 'Nguhanthonynche', 'tonybillions@icloud.com', 'images/empty.jpg', NULL, 0, 0, NULL, NULL, NULL, 'clinton', '$2y$10$NhZpZiRdgA45sYSwdsZ/Yu8zvnvGMpBx1YimVpaf/TecwFxZv0Qly', NULL, '2022-08-13 00:09:06', '2022-08-13 00:09:06'),
(70, 'ASTILL', 'danieldjiogue@gmail.com', 'images/empty.jpg', NULL, 0, 0, NULL, NULL, NULL, 'clinton', '$2y$10$tLBi6Y.GZXYn9RcnP2B/yeekmvOxmkVZDzNXHq7JvuMUL9N9i/Veq', NULL, '2022-08-14 19:58:07', '2022-08-14 19:58:07'),
(71, 'Criptorene', 'chiarenembu@gmail.com', 'images/empty.jpg', '2022-08-15 08:21:00', 0, 0, NULL, NULL, NULL, 'Dukandasight', '$2y$10$HtSsdEi8Qyyrm.SaUPDJheaOf.U0KB5GQgqiznYWm2.4T.AIs4yHC', NULL, '2022-08-15 08:19:42', '2022-08-15 08:21:00'),
(72, 'Ekwenkum philip', '237simonphilip@gmail.com', 'profiles/c3zrysFBlLMqPyVLvQE8dq1ygw3iK4mrXCdwcmtP.jpg', '2022-08-15 21:51:44', 0, 0, NULL, NULL, NULL, 'clinton', '$2y$10$wu0VpvjfwCngzQvJmFw6HuF0J/k41dnRzRcaeCeGWBVc1bhtPBuDG', 'mojTLRDaNIb0msq9Krsc0thXg2atdY8Vx89fqUtuEqbMial9roNX7c6RYwYj', '2022-08-15 21:50:35', '2022-08-16 18:44:43'),
(73, 'Yeshua1', 'gloireg29@gmail.com', 'images/empty.jpg', '2022-08-15 23:31:15', 0, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$gjkESdQGNX5jRhmPUvOfLeThyZgXwMQFtTxGva46AZPBT7yJboYJa', NULL, '2022-08-15 23:30:30', '2022-08-15 23:31:15'),
(74, 'Boi', 'Promiseakem38@gmail.com', 'images/empty.jpg', NULL, 0, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$93SRdOoUTnt53Q5LfSnT3eYfUyQGifYtlxnoy1kAkDhZHQc8LwJea', 'L4SfEeiwKg4SKqGYdCwkPG8LIVdcJeYFbM7HWYkC1t4nzSe1oBLMOjqO1GZ6', '2022-08-17 05:20:27', '2022-08-17 05:20:27'),
(75, 'Rutherfordzara', 'rutherfordzara6@gmail.com', 'profiles/X2IAffszR7MSNJds3UIAgVEUlftZp28vnRtzu7Fc.jpg', '2022-08-17 20:21:54', 0, 0, NULL, NULL, NULL, NULL, '$2y$10$G5n/5MI3SpH7JmbdcVGiB.cg3ELrIcwptpDBY6H9FgoQA5npR8cku', NULL, '2022-08-17 20:20:21', '2022-08-17 20:21:54'),
(76, 'Abang29900', 'ekwelletikuwisdomabang@gmail.com', 'images/empty.jpg', '2022-08-18 14:20:37', 0, 0, NULL, NULL, NULL, 'clinton', '$2y$10$wzpmqUFAHFUSMNaR97nxYuNh9WwnKTac9/piIxsQ0XEV0Ja/ftUoi', NULL, '2022-08-18 14:17:15', '2022-08-18 14:20:37'),
(77, 'Magie Kok', 'fuambruhrolins@gmail.com', 'images/empty.jpg', '2022-08-18 16:39:08', 0, 0, NULL, NULL, NULL, 'clinton', '$2y$10$2HNisNxqzFUNHxcR8f.7UO5eT2zAxJVe91ImgGS0F/z9I2umbAn5y', NULL, '2022-08-18 16:38:09', '2022-08-18 16:39:08'),
(78, 'OBASE AKPEMEKE', 'Michelasams639@gmail.com', 'images/empty.jpg', NULL, 0, 0, NULL, NULL, NULL, 'clinton', '$2y$10$Jjn7iWqQeKgEN4NiPvaNh.8sZ/u8QRrWUTXwBjIKCbkFEXfz/6wfO', NULL, '2022-08-18 20:21:07', '2022-08-18 20:21:07'),
(79, 'hatangba', 'hatangba@gmail.com', 'images/empty.jpg', '2022-08-19 02:54:41', 0, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$QjY35MiEiYde1sDq11/8ju7MtcOViFyPfheXJtdxKoWPBRwk5Lcuu', NULL, '2022-08-19 02:44:15', '2022-08-19 02:54:41'),
(80, 'Djenny', 'Martiidjenny@gmail.com', 'profiles/Pr0KLWNnDXxG98ZAlxbrCOCoR9iwJOHJxvKaV2iS.jpg', NULL, 0, 0, NULL, NULL, NULL, 'clinton', '$2y$10$Mm6fxcQY7lLogXuGkePxS.xRQ4WyBa56QzHuCEdKVxq6.eCQ2FgSu', NULL, '2022-08-21 18:34:25', '2022-08-21 18:34:25'),
(81, 'Elkenzo', 'elohimntah@gmail.com', 'images/empty.jpg', '2022-08-21 18:55:51', 0, 0, NULL, NULL, NULL, NULL, '$2y$10$rhwcCFWdmPBH/Fml8.CJB.O9Z6P9HfPgCtSRIptpPhxUdECkhyVTm', 'SlBR75iVZtpabpxLdrqnc2iBdhfTyexuHvh3O1Iva9RigLi0C1wEdAvKCSZj', '2022-08-21 18:51:51', '2022-08-21 18:55:51'),
(82, 'Celine', 'Celinenguo2@icloud.com', 'images/empty.jpg', NULL, 0, 0, NULL, NULL, NULL, NULL, '$2y$10$Sd85UUr1BvQDQm8VH5w99eD3dtPivA09kS79agBHNpHO4ycwPEM2m', NULL, '2022-08-23 02:36:59', '2022-08-23 02:36:59'),
(83, 'Kalen bless', 'kalangbless@gmail.com', 'images/empty.jpg', NULL, 0, 0, NULL, NULL, NULL, 'clinton', '$2y$10$VJDiuJll/bzRN6s2RjI5Cugqb9lrpPLEZEawrmj4tHgP6I7jwbWw2', NULL, '2022-08-23 19:43:56', '2022-08-23 19:43:56'),
(84, 'Zee Precious', 'zeeprecious133@gmail.com', 'images/empty.jpg', '2022-08-25 05:14:00', 0, 0, NULL, NULL, NULL, 'clinton', '$2y$10$3s4JN2191CWF8sJijbH7hObfsfE0dsON9TSw.0imdXA2Kb.Py6GYm', NULL, '2022-08-25 04:49:32', '2022-08-25 05:14:00'),
(85, 'Tabiayuk stephane', 'tabiayukstephane@email.com', 'profiles/IiP45rRwpTqrVRIboc8R1sHy5PiMIGlmxXbUNo0k.jpg', '2022-08-25 20:56:11', 6545, 1005, NULL, NULL, NULL, 'clinton', '$2y$10$WV.4xY5cVvcWrJONY/COdOzISdayqTq7TeGWGrs5v5kPEDoWgU8YG', '9wz0OsCQ11eskl1ruiz8mVo05K8sZ1rtYLTB0BI9Ws01iJWemedJN9rlm8Oj', '2022-08-25 05:49:40', '2022-09-24 07:00:03'),
(86, 'Teku cephas', 'tekotitus3@gmail.com', 'images/empty.jpg', '2022-10-22 16:12:55', 0, 0, NULL, NULL, NULL, 'clinton', '$2y$10$VzTEbWygqPOrRNEjUC8m0.cZt9eoTOGUR2VLw5suTELTQHjgIVkNW', 'OArSsFxKGJGOnx8uEaygFsDDIHq4sQKmGGqJyNpZyfrnHPOIJ9l4XZ2bEG4f', '2022-08-25 23:01:11', '2022-10-22 16:12:55'),
(87, 'EL ZAZU', 'ngongfreezy3@gmail.com', 'images/empty.jpg', '2022-08-26 06:55:15', 0, 0, NULL, NULL, NULL, 'clinton', '$2y$10$P5L8odZPib/39FXiPBGv.OpEySuheLTNQ1NUfagBzBUxQbWDNc5BG', NULL, '2022-08-26 06:51:19', '2022-08-26 06:55:15'),
(88, 'Blandine', 'bihblandine211@gmail.com', 'images/empty.jpg', '2022-08-27 23:38:57', 8000, 50, NULL, NULL, NULL, 'Clinton', '$2y$10$ImxOonzJR2QYTcDBe65dA.6/lg6tVpvVqhhxDAIi5ww9Ft9EPjura', NULL, '2022-08-27 21:58:22', '2022-09-27 19:06:26'),
(89, 'Tabiayuk kelvin Akem', 'Tabiayukkelvin@email.com', 'profiles/bSke9KNED4iUa2QQ4qMkqZgwE9CK8JsnwsePZ2j8.jpg', NULL, 0, 0, NULL, NULL, NULL, 'clinton', '$2y$10$DdXR5rHrJ.GoI2GUeO8Wu.nutb9ZOhGdFtXpe5KlIvq0qhV0d14RK', NULL, '2022-08-28 14:25:02', '2022-08-28 14:25:02'),
(90, 'AYUK NELSON', 'Ayuknelson@email.com', 'profiles/gOAQwm5d0wl7WD10XHtQ0UDnKyUhvIxO1cBQaSqA.jpg', NULL, 0, 0, NULL, NULL, NULL, 'clinton', '$2y$10$nk0m8nwEth4ebB4jhJZE4ezmy9TAAFffKaf.b5xsEqdamFxcXF7wW', NULL, '2022-08-30 01:25:31', '2022-08-30 01:25:31'),
(91, 'Mohbad', 'nyambotf@gmail.com', 'images/empty.jpg', '2022-08-30 02:17:41', 0, 0, NULL, NULL, NULL, 'Clinton', '$2y$10$BpI2eLN5LbaONfVbHrIwIOfDbYRdJfost8a/6eu65fP9Q5dpZSycm', NULL, '2022-08-30 02:16:28', '2022-08-30 02:17:41'),
(92, 'Oswald', 'medahosvald@gmail.com', 'images/empty.jpg', NULL, 0, 0, NULL, NULL, NULL, 'clinton', '$2y$10$7..jFAc5cxOgMePSHdvgnelRY.QVk7YggaSSluhA1s/JRrvlwDtl.', NULL, '2022-08-31 16:04:36', '2022-08-31 16:04:36'),
(93, 'Brandy', 'zidanebrandy4@gmail.com', 'images/empty.jpg', NULL, 0, 0, NULL, NULL, NULL, 'clinton', '$2y$10$QUQSJy4NFZ2qPsNY3BXiT.cep9mnOXnxnWJ0ISwn2dnt7ysKujVJS', NULL, '2022-09-02 19:22:40', '2022-09-02 19:22:40'),
(94, 'David', 'stakingword2022@proton.me', 'images/empty.jpg', '2022-11-10 15:46:22', 0, 0, NULL, NULL, NULL, NULL, '$2y$10$Bk.g7x/6fu.xet0xTgWRCeBl8ALZug/GSGen4/h4tKctpCyNz2.8G', NULL, '2022-11-10 15:46:01', '2022-11-10 15:46:22'),
(95, 'CS0974157', 'shatrughankumar446@gmail.com', 'images/empty.jpg', '2022-12-27 14:43:16', 0, 0, NULL, NULL, NULL, NULL, '$2y$10$YOgKcARFHtFNkW4lfZWH7emnOIW7C8X3yMu1VbhvpZWC.GUYYwRLO', NULL, '2022-12-27 14:42:03', '2022-12-27 14:43:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `test`
--
ALTER TABLE `test`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
